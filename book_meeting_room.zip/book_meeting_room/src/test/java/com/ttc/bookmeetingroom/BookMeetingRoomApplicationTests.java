package com.ttc.bookmeetingroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMeetingRoomApplicationTests {

    @Test
    void contextLoads() {
    }

}

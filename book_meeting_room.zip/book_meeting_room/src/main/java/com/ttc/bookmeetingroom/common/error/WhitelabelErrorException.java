package com.ttc.bookmeetingroom.common.error;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class WhitelabelErrorException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6177713163507973882L;

}

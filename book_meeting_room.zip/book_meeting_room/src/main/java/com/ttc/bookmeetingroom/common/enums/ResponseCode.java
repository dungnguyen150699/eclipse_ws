package com.ttc.bookmeetingroom.common.enums;

public interface ResponseCode {
}

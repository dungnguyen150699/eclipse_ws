Mini project booking meeting room for ttc-solution

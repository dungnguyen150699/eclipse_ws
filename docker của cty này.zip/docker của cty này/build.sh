docker build -t landing-page-1.0.0 -f Dockerfile .
